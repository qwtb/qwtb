function f=freq(x)
X=fft(x);
Xa=abs(X);
N=length(X);
[Xamax, ind]=max(Xa(2:round(N/2)));
if (ind==1) % Enn�l kisebb nem lehet a feltev�s szerint (legal�bb 1 per.)
ii=ind;
jj=ii+1;
else
ii=ind;
if (Xa(ind-1)<Xa(ind+1))
jj=ii+1;
else
jj=ii+1;
end;
end;
Ui=real(X(ii+1));
Vi=imag(X(ii+1));
Uj=real(X(jj+1));
Vj=imag(X(jj+1));
n=2*pi/N;
Kopt=(sin(n*ii*(Vj-Vi))+cos(n*ii*(Uj-Ui)))/(Uj-Ui);
Z2=Vj*((Kopt-cos(n*jj))/sin(n*jj))+Uj;
Z1=Vi*((Kopt-cos(n*ii))/sin(n*ii))+Ui;
lambda=1/n*acos((Z2*cos(n*(ii+1))-Z1*cos(n*ii))/(Z2-Z1));
f=lambda;
		
		