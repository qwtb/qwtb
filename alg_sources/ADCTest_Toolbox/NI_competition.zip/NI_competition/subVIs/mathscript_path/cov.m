function K=cov(A0,A1,A2,bins,Nx)
Mb=length(bins);
K=zeros(Mb);
pp=[...
    A2/2;
    A1/2;
    A0;
    A1/2;
    A2/2;
    ];
c0=pp.'*pp;
c1=pp(1:4).'*pp(2:5);
c2=pp(1:3).'*pp(3:5);
c3=pp(1:2).'*pp(4:5);
c4=pp(1)*pp(5);
for ii=1:Mb
    for jj=1:Mb
        d=abs(bins(ii)-bins(jj)); % d lehet [0,1,2,...,N-1]
        if (d>Nx/2)
            d=abs(d-Nx); % Ha a t�vols�g pl. N-k, az val�j�ban k!
        end
        switch(d)
            case 0
                K(ii,jj)=c0;
            case 1
                K(ii,jj)=c1;
            case 2
                K(ii,jj)=c2;
            case 3
                K(ii,jj)=c3;
            case 4
                K(ii,jj)=c4;
            otherwise
                K(ii,jj)=0;
        end
    end
end
end