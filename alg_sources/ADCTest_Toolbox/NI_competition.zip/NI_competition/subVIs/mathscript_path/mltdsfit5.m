function [Aml, Bml, Cml, fml, Sigmaml]=mltdsfit5(data,A,B,C,f,NoB,INL,erms)

MAX_ITER_DEFAULT = 30;
MAX_FUN_EVALS_DEFAULT = 60;
% TOL_FUN_DEFAULT = 0;
LAMBDA_ADJUST = 10;

%Setting "global" optimization variables:
p = ones(5,1)*NaN;
CF = NaN; 
% PML = NaN; 
grad = ones(5,1)*NaN;
hess = ones(5)*NaN;
l = 0;

%Getting initial estimators:
M=length(data);
p(1:2)=1/(2^NoB-2)*[A -B]';
p(3)=(C-0.5)/(2^NoB-2);
p(4)=2*pi*f/M;
% pure_sinewave=p(1)*cos(((1:M).')*p(4)) + p(2)*sin(((1:M).')*p(4)) + p(3);

%Treating unestimated transition levels: INL linearly reaches 0
lowest_estimated = find(~isnan(INL),1,'first');
highest_estimated = find(~isnan(INL),1,'last');
S=size(INL);
if (S(1)<S(2))
    INL=INL.';
end;
INL = [linspace(0,INL(lowest_estimated),lowest_estimated).';INL(lowest_estimated+1:highest_estimated-1);linspace(INL(highest_estimated),0,length(INL)-highest_estimated+1).'];
% translevels = zeros(length(INL),1);
% translevels(1) = 0;
% translevels(end) = 1;
% Q = (translevels(end)-translevels(1))/(length(translevels)-1); %V/(2^B-2)
% k=2:(length(translevels)-1);
% translevels(k)=translevels(1)+Q*(-1+k)+INL(k)*Q;
% clear Q k;

%Calculating initial estimator of noise
%To get initial noise estimator, 10000 samples of quantized pure sinewave
%are enough

p(5) = 5*erms/(2^NoB-2);
%Adjusting initial noise variance estimator: in case of arbitrary low noise
%a higher initial estimator is required to be able to perform computations
if (p(5) < eps)
    p(5) = 0.1/(2^NoB-2); %0.1 LSB
end

iteration_counter = 0;
evaluation_counter = 0;
b=true;

[PML,CF,grad,hess] = EvaluateCF(data,p,NoB,INL);
% [PML,CF,grad,hess] = EvaluateCF(data,p,NoB,INL,L);
l = max(max(hess));
 
while(b)
  p_next = p - pinv(hess + l*eye(5))*grad;
  % p_next=p-(hess+l*eye(5))\grad;
	while (p_next(5) < 0)
		l  = l*LAMBDA_ADJUST;
		p_next = p - pinv(hess + l *eye(5))*grad;
        % p_next=p-(hess+l*eye(5))\grad;
	end
    [PML_next,CF_next] = EvaluateCF(data,p_next,NoB,INL);
    % [PML_next,CF_next] = EvaluateCF(data,p_next,NoB,INL, L);
    evaluation_counter = evaluation_counter + 1;
	while (CF_next > CF)
        l = l*LAMBDA_ADJUST;
        p_next = p - pinv(hess + l*eye(5))*grad;
        % p_next=p-(hess+l*eye(5))\grad;
        while (p_next(5) < 0)
            l  = l*LAMBDA_ADJUST;
            p_next = p - pinv(hess + l *eye(5))*grad;
            % p_next=p-(hess+l*eye(5))\grad;
        end
        [PML_next,CF_next] = EvaluateCF(data,p_next,NoB,INL);
        % [PML_next,CF_next] = EvaluateCF(data,p_next,NoB,INL, L);
        evaluation_counter = evaluation_counter + 1;
	end
	[PML_next,CF_next,grad_next,hess_next] = EvaluateCF(data,p_next,NoB,INL);
    % [PML_next,CF_next,grad_next,hess_next] = EvaluateCF(data,p_next,NoB,INL,L);
    evaluation_counter = evaluation_counter + 1;
	l = l*(1/LAMBDA_ADJUST);
	p = p_next;
    CF = CF_next;
    PML = PML_next;
    grad = grad_next;
    hess = hess_next;
	b=((iteration_counter<MAX_ITER_DEFAULT)&(evaluation_counter<MAX_FUN_EVALS_DEFAULT));
end
Aml=(2^NoB-2)*p(1);
Bml=-(2^NoB-2)*p(2);
Cml=(2^NoB-2)*p(3);
fml=1/2/pi*p(4)*length(data);
Sigmaml=(2^NoB-2)*p(5);

 





