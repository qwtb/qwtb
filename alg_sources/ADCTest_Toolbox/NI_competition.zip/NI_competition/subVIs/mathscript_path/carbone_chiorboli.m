function b=carbone_chiorboli(N,J,dJ)
cc=1/2/N;
g=gcd(N,J);
b=false;
if ((g==1)&&(abs(dJ)<cc))
	b=true;
end;