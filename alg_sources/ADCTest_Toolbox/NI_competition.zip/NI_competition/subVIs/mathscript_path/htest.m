function [tl,INL,DNL]=htest(xk,C,R,b)

CUTOFF_RATIO = 0.25;
EDGE_CUTOFF = 0.1;

edges=1:2^b;
h=histc(xk,edges);
nh=1/sum(h)*h;
nch=cumsum(nh);

mu=(C-0.5)/(2^b-2);
A=(R/(2^b-2));

tl=mu-A*cos(pi*nch(1:end-1));
small=0.1/sum(h);
tl(abs(nch(1:end-1))<small)=NaN;
tl(abs(nch(1:end-1)-1)<small)=NaN;

itl=linspace(0,1,(2^b-1));
Stl=size(tl);
if (Stl(1)>Stl(2))
itl=itl';
end
q = 1/(2^b - 2);
INL = 1/q*(tl-itl);

INL((nch(1:end-1)<EDGE_CUTOFF)|(nch(1:end-1)>(1-EDGE_CUTOFF)))=NaN;
lowest_estimated = find(~isnan(INL),1,'first');
highest_estimated = find(~isnan(INL),1,'last');
INL_calib = [zeros(lowest_estimated-1,1);linspace(INL(lowest_estimated),INL(highest_estimated),highest_estimated-lowest_estimated+1).';zeros(length(INL)-highest_estimated,1)];
if (size(INL)~=size(INL_calib))
    INL_calib=INL_calib';
end;
INL = INL - INL_calib;
DNL=diff(INL);





