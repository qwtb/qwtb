function [x, R, Fi, dc, f]=clipped_sine(x0)
Ctr=1.001; % K�sz�b�rt�k
sx0=size(x0);
if (sx0(1)>sx0(2)) % oszlopvektor
    x0=x0.';
end; % �gy m�r sorvektor
N0=length(x0);
xhann=(x0-mean(x0)*ones(size(x0))).*(0.5*(1-cos(2*pi*(0:N0-1)/N0))); % Hann ablak, a dc-t elimin�ljuk amennyire csak tudjuk
Yhann=fft(xhann);
[Unused, maxind]=max(abs(Yhann(2:round(N0/2)))); % DC-t nem n�zz�k
f0=maxind; % Most nem vonunk le egyet a matlab t�mbindexel�se miatt, mivel a maximumot a 2. elemt�l kerest�k egy sorral feljebb
maxind=maxind+1; % A maximumot a m�sodik elemt�l kerest�k! A teljes jelben teh�t egyel arr�bb ker�l a maximum �rt�ke!
Fi0=atan2(imag(Yhann(maxind)), real(Yhann(maxind))); %kezdeti becsl�
if (abs(Yhann(maxind-1))>=abs(Yhann(maxind+1)))
    seged1=abs(Yhann(maxind));
    seged2=abs(Yhann(maxind-1));
    df=(seged1-2*seged2)/(seged1+seged2);
else
    seged1=abs(Yhann(maxind));
    seged2=abs(Yhann(maxind+1));
    df=(2*seged2-seged1)/(seged2+seged1);
end
f=f0+df; % korrig�lt frekvenciabecsl�
dFi=-df*pi;
Fi=Fi0+dFi; % korrig�lt f�zisbecsl�
J=fix(f);
N=round(J/f*N0); % A �s dc becsl�s�hez kb. koherens jel kell, eldobjuk a t�rt peri�dust
x1=x0(1:N); % Kb. koherens r�sz
Vmax=max(x1);
Vmin=min(x1);
Kt=nnz(x1==Vmax); % Ennyi pont van a legnagyobb k�dban
Kb=nnz(x1==Vmin); % Ennyi a legkisebben
teta1=pi*(0.5-(Kt-1)/N);
teta2=pi*(1.5-(Kb-1)/N);
p=pinv([sin(teta1), 1; sin(teta2), 1])*[Vmax; Vmin];
R=p(1);
dc=p(2);
% R �s dc becsl�se k�sz, �jra a teljes jelhosszt haszn�ljuk
x=x0;
t=0:N0-1;
if ((dc+R)>(Ctr*Vmax))
    tmaxind=(x0==Vmax);
    x(tmaxind)=dc+R*cos(2*pi*f*t(tmaxind)/N0+Fi);
end
if ((dc-R)<(Ctr*Vmin))
    tminind=(x0==Vmin);
    x(tminind)=dc+R*cos(2*pi*f*t(tminind)/N0+Fi);
end

