function [Nc, Jc]=coherency(N0, f0)
J=1:round(f0);
mintatav_binben=f0/N0;
N=round(1/mintatav_binben*J);
CC=1/2./N;
f=mintatav_binben*N;
dJ=f-J;
G=gcd(N,J);
ind=((G==1)&(abs(dJ)<CC));
Jc=max(J(ind));
Nc=max(N(ind));
% J=round(f0); 
% dJ=f0-J; 
% b=carbone_chiorboli(N0, J, dJ);
% N=N0;
% if (b==false)
%     J=floor(f0); 
%     mintatav_binben=f0/N0; 
%     N=round(J/mintatav_binben); 
%     f=N*mintatav_binben; 
%     dJ=f-J; 
%     b=carbone_chiorboli(N, J, dJ);
%     while (b==false);
%         J=J-1;
%         N=round(J/mintatav_binben);
%         f=N*mintatav_binben;
%         dJ=f-J;
%         b=carbone_chiorboli(N, J, dJ);
%         if (J==0)
%             break;
%         end
%     end
% end
% Nc=N;
% Jc=J;
