function [A,B,C,f]=fdsfit4(x)

s=size(x);
if (s(2)>s(1)) % Ha sorvektor, oszlopp� alak�tjuk.
x=x.';
end;

Nx=length(x);
n=(0:Nx-1).';

A0=+4.243800934609435e-001;
A1=-4.973406350967378e-001;
A2=+7.827927144231873e-002;

wbh3=A0+A1*cos(2*pi*n/Nx)+A2*cos(4*pi*n/Nx);

xbh3=x.*wbh3;
Xbh3teljes=fft(xbh3);
% binbh3teljes=(0:Nx-1).';

A=0;
B=0;
C=0;
f=freq(x);
k=round(f);

bins=([-2:2, k-2:k+2, Nx-k-2:Nx-k+2]).';
inds0=(bins<0);
bins(inds0)=Nx+bins(inds0);
indsN=(bins>(Nx-1));
bins(indsN)=-Nx+bins(indsN);
bins=unique(bins);

inds=ismember((0:Nx-1).', bins);
Xbh3m=Xbh3teljes(inds);

K=cov(A0,A1,A2,bins,Nx);

[limit,sf,p]=pol(Nx);

It_szam=10;

for ii=1:It_szam
[Xbh3,Unused,dAbh3,dBbh3,dCbh3,dfbh3]=g2(A,B,C,f,Nx,bins,limit,sf,p,A0,A1,A2);
e=Xbh3m-Xbh3;
J=[dAbh3, dBbh3, dCbh3, dfbh3];
dP=pinv(real(J'*pinv(K)*J))*real(J'*pinv(K)*e);
A=A+dP(1);
B=B+dP(2);
C=C+dP(3);
f=f+dP(4);
end;