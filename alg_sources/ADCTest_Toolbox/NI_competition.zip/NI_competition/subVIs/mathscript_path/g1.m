function [Xbins,Xr,dAr,dBr,dCr,dfr]=g1(A,B,C,f,N,bins,limit,sf,p)
% Seg�dv�ltoz�k
M=length(bins);
X_sin=zeros(M,1);
X_dc=zeros(M,1);
% Visszat�r�si �rt�k strukt�r�ja
% X_rect.bin=bins;
% X_rect.X=zeros(M,1);
% X_rect.dA=zeros(M,1);
% X_rect.dB=zeros(M,1);
% X_rect.dC=zeros(M,1);
% X_rect.df=zeros(M,1);
% Visszat�r�si t�mb�k inicializ�l�sa
Xr=zeros(M,1);
dAr=zeros(M,1);
dBr=zeros(M,1);
dCr=zeros(M,1);
dfr=zeros(M,1);
Xbins=bins;
% A spektrum kisz�m�t�sa az adott bineken
for ii=1:M
    m=bins(ii);
    if (rem(m,N)==0)
        X_dc(ii)=C*N;
        dCr(ii)=N;
    end;
    f1=fix(f);
    f2=f-f1;
    d1=(m-f)/N;
    d2=(m+f)/N;
    e1=((-1)^(m+f1))*exp(1i*(f2+d1)*pi);
    e2=((-1)^(m+f1))*exp(1i*(-f2+d2)*pi);
    %e1=exp(1i*(f2+d1)*pi);
    %e2=exp(1i*(-f2+d2)*pi);
    de1_df=((-1)^(m+f1))*1i*pi*(N-1)/N*e1;
    de2_df=((-1)^(m+f1))*(-1i)*pi*(N-1)/N*e2;
    %de1_df=1i*pi*(N-1)/N*e1;
    %de2_df=-1i*pi*(N-1)/N*e2;
    b1=(A+1i*B)/2;
    b2=(A-1i*B)/2;
    n1=sin((d1)*pi);
    if (abs(n1)>=limit)
        sz1=((-1)^(m+f1))*sin(-f2*pi);
        % sz1=sin(-f2*pi);
        dsz1_df=((-1)^(m+f1))*(-pi)*cos(f2*pi);
        % dsz1_df=-pi*cos(f2*pi); % !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        dn1_df=-pi/N*cos((d1)*pi);
        sqr_n1=(1-cos(2*pi*d1))/2;
        r1=sz1/n1;
        dr1_df=(dsz1_df*n1-dn1_df*sz1)/sqr_n1;
    else
        % A sin(N*d1*pi)/sin(d1*pi) h�nyadost k�zel�t� polinomot 0 k�r�l sz�m�tjuk ki, majd a
        % megfelel� ir�nyba "elforgatjuk"
        w01=(d1-round(d1))*pi; % 0 k�r� vissz�k a frekvenci�t
        w1=sf*w01; % �tsk�l�zzuk
        r1=polyval(p(end:-1:1),w1); % Az "�ll�" polinom meghat�roz�sa
        q=polyder(p(end:-1:1)); % A deriv�lt egy�tthat�i
        dr1_df=polyval(q,w1); % A deriv�lt meghat�roz�sa
        if (rem(N,2)==0) % A pontsz�m p�ros
            if (rem(round(d1),2)~=0) % d1 p�ratlan (vagy ak�zeli)
                r1=-r1;
                dr1_df=-dr1_df;
            end; % Csak ebben az esetben kell forgatnunk!
        end;
    end;

    n2=sin((d2)*pi);
    if (abs(n2)>=limit)
        sz2=((-1)^(m+f1))*sin(f2*pi); 
        %sz2=sin(f2*pi);
        dsz2_df=((-1)^(m+f1))*pi*cos(f2*pi);
        % dsz2_df=pi*cos(f2*pi); % !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        dn2_df=pi/N*cos((d2)*pi);
        sqr_n2=(1-cos(2*pi*d2))/2;
        r2=sz2/n2;
        dr2_df=(dsz2_df*n2-dn2_df*sz2)/sqr_n2;
    else % Ugyanaz, mint fent
        w02=(d2-round(d2))*pi;
        w2=sf*w02;
        r2=polyval(p(end:-1:1),w2);
        q=polyder(p(end:-1:1));
        dr2_df=polyval(q,w2);
        if (rem(N,2)==0)
            if (rem(round(d2),2)~=0)
                r2=-r2;
                dr2_df=-dr2_df;
            end;
        end;

    end;
    X_sin(ii)=e1*b1*r1+e2*b2*r2;
    % X_rect.X(ii)=X_sin(ii)+X_dc(ii);
    % X_rect.dA(ii)=e1/2*r1+e2/2*r2;
    % X_rect.dB(ii)=1i*e1/2*r1-1i*e2/2*r2;
    % X_rect.df(ii)=de1_df*b1*r1+e1*b1*dr1_df+de2_df*b2*r2+e2*b2*dr2_df;
	Xr(ii)=X_sin(ii)+X_dc(ii);
	dAr(ii)=e1/2*r1+e2/2*r2;
	dBr(ii)=1i*e1/2*r1-1i*e2/2*r2;
	dfr(ii)=de1_df*b1*r1+e1*b1*dr1_df+de2_df*b2*r2+e2*b2*dr2_df;
end
end