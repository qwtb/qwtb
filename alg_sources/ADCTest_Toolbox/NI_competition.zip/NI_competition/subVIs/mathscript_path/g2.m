function [Xbh3,bin,dAbh3,dBbh3,dCbh3,dfbh3]=g2(A,B,C,f,Nx,bins,limit,sf,p,A0,A1,A2)
s=size(bins);
if (s(2)>s(1)) % Sorvektor
bins=bins.';
end;

Mb=length(bins);
bin=bins;
Xbh3=zeros(Mb,1);
dAbh3=zeros(Mb,1);
dBbh3=zeros(Mb,1);
dCbh3=zeros(Mb,1);
dfbh3=zeros(Mb,1);

a=[A2/2; A1/2; A0; A1/2; A2/2;];

rect_bins=unique([-2+bins; -1+bins; bins; 1+bins; 2+bins;]);

[Xbins,Xr,dAr,dBr,dCr,dfr]=g1(A,B,C,f,Nx,rect_bins,limit,sf,p);

for ii=1:Mb
    m=bin(ii);
    rect_inds=ismember(rect_bins, (m-2:m+2).');
    Xbh3(ii)=a.'*Xr(rect_inds);
    dAbh3(ii)=a.'*dAr(rect_inds);
    dBbh3(ii)=a.'*dBr(rect_inds);
    dCbh3(ii)=a.'*dCr(rect_inds);
    dfbh3(ii)=a.'*dfr(rect_inds);
end